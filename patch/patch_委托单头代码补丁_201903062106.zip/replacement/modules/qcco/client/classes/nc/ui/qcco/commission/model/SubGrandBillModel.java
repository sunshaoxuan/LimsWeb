package nc.ui.qcco.commission.model;

import nc.ui.pubapp.uif2app.model.BillManageModel;

public class SubGrandBillModel extends BillManageModel {
	private nc.ui.pubapp.uif2app.components.grand.ListGrandPanelComposite billListView;

	public void initModel(Object data) {
		super.initModel(data);
	}

	public nc.ui.pubapp.uif2app.components.grand.ListGrandPanelComposite getBillListView() {
		return billListView;
	}

	public void setBillListView(nc.ui.pubapp.uif2app.components.grand.ListGrandPanelComposite billListView) {
		this.billListView = billListView;
	}
}
