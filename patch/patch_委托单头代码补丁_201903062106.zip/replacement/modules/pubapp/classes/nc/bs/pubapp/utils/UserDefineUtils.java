package nc.bs.pubapp.utils;

import java.util.Vector;

import nc.ui.bd.ref.AbstractRefModel;
import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.beans.UITable;
import nc.ui.pub.beans.constenum.DefaultConstEnum;
import nc.ui.pub.beans.constenum.IConstEnum;
import nc.ui.pub.bill.BillItem;
import nc.vo.pub.ISuperVO;

public class UserDefineUtils {

	public static void refreshItemRefValue(ISuperVO vo, UITable uiTable, int row, BillItem billItem,
			boolean onlyDisplayItem) {
		if (billItem != null && (!onlyDisplayItem || billItem.isShow())) {
			UIRefPane pane = (UIRefPane) billItem.getComponent();
			AbstractRefModel refModel = pane.getRefModel();
			if (vo.getAttributeValue(billItem.getKey()) != null) {
				Vector refvls = refModel.matchData(refModel.getPkFieldCode(),
						(String) vo.getAttributeValue(billItem.getKey()));
				if (null != refvls) {
					IConstEnum val = new DefaultConstEnum(((Vector) refvls.get(0)).get(0),
							(String) ((Vector) refvls.get(0)).get(1));
					for (int col = 0; col < uiTable.getColumnCount(); col++) {
						if (uiTable.getColumnName(col).equals(billItem.getName())) {
							uiTable.setValueAt(val, row, col);
						}
					}
				}
			}
		}
	}

}
