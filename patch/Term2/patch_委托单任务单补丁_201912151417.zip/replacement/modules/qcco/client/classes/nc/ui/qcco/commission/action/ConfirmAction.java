package nc.ui.qcco.commission.action;

import java.awt.event.ActionEvent;

import nc.ui.uif2.NCAction;

public class ConfirmAction extends NCAction {

	/**
	 * serial no
	 */
	private static final long serialVersionUID = -8853899124022548970L;

	public ConfirmAction() {
		setBtnName("ȷ��");
		setCode("ConfirmAction");
	}

	@Override
	public void doAction(ActionEvent arg0) throws Exception {
		// TODO �ԄӮa���ķ��� Stub

	}

}
