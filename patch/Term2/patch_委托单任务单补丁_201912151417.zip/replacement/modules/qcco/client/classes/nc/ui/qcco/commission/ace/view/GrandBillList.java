package nc.ui.qcco.commission.ace.view;

import nc.ui.pubapp.uif2app.view.ShowUpableBillListView;

public class GrandBillList extends ShowUpableBillListView {
	/**
	 * serial no
	 */
	private static final long serialVersionUID = -2046993994573261110L;

	public void initUI() {
		super.initUI();
	}

}
