package nc.ui.qcco.task.model;

import nc.ui.pubapp.uif2app.model.BillManageModel;

public class SubGrandBillModel extends BillManageModel {

	public void initModel(Object data) {
		super.initModel(data);
	}
}
