package nc.ui.pub.qcco.writeback.utils.LIMSVO;

public class Test extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 929620256192581242L;

}
