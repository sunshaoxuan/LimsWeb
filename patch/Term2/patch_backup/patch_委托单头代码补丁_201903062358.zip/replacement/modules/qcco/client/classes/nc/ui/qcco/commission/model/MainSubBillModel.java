package nc.ui.qcco.commission.model;

import nc.bs.pubapp.utils.UserDefineUtils;
import nc.ui.pub.bill.BillItem;
import nc.ui.pubapp.uif2app.model.BillManageModel;
import nc.ui.pubapp.uif2app.view.ShowUpableBillListView;
import nc.vo.pub.ISuperVO;
import nc.vo.qcco.commission.AggCommissionHVO;
import nc.vo.qcco.commission.CommissionBVO;

import org.apache.commons.lang.StringUtils;

public class MainSubBillModel extends BillManageModel {
	private nc.ui.pubapp.uif2app.components.grand.ListGrandPanelComposite billListView;

	public void initModel(Object data) {
		super.initModel(data);

		// ˢ���б�ҳ���Զ��������ʾֵ
		// ֻˢ���������ӱ�������ڵ���ӱ���ˢ��
		AggCommissionHVO aggvo = (AggCommissionHVO) this.getSelectedData();
		if (aggvo != null) {
			ShowUpableBillListView view = ((ShowUpableBillListView) this.getBillListView().getMainPanel());
			ISuperVO headVO = aggvo.getParentVO();
			for (int row = 0; row < view.getBillListPanel().getBodyBillModel().getRowCount(); row++) {
				for (BillItem item : view.getBillListPanel().getHeadBillModel().getBodyItems()) {
					if (!StringUtils.isEmpty(item.getRefType()) && item.getRefType().contains("<")) {
						UserDefineUtils.refreshItemRefValue(headVO, view.getBillListPanel().getHeadTable(), row, item,
								true);
					}
				}
			}

			for (int row = 0; row < view.getBillListPanel().getBodyBillModel().getRowCount(); row++) {
				CommissionBVO bodyVO = (CommissionBVO) view.getBillListPanel().getBodyBillModel()
						.getBodyValueRowVO(row, CommissionBVO.class.getName());
				ISuperVO[] aggBodies = aggvo.getChildren(CommissionBVO.class);
				CommissionBVO fullBodyVO = null;
				for (ISuperVO realBody : aggBodies) {
					if (bodyVO.getPk_commission_b().equals(realBody.getAttributeValue("pk_commission_b"))) {
						fullBodyVO = (CommissionBVO) realBody;
						break;
					}
				}
				for (BillItem item : view.getBillListPanel().getBodyBillModel().getBodyItems()) {
					if (!StringUtils.isEmpty(item.getRefType()) && item.getRefType().contains("<")) {
						UserDefineUtils.refreshItemRefValue(fullBodyVO, view.getBillListPanel().getBodyTable(), row,
								item, true);
					}
				}
			}
		}
		//
	}

	public nc.ui.pubapp.uif2app.components.grand.ListGrandPanelComposite getBillListView() {
		return billListView;
	}

	public void setBillListView(nc.ui.pubapp.uif2app.components.grand.ListGrandPanelComposite billListView) {
		this.billListView = billListView;
	}
}
