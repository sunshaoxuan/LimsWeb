package nc.ui.qcco.commission.ace.handler;

import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.bill.BillItem;
import nc.ui.pubapp.uif2app.event.IAppEventHandler;
import nc.ui.pubapp.uif2app.event.card.CardBodyBeforeEditEvent;
import nc.ui.qcco.commission.refmodel.SampleInfoRefModel;
import nc.ui.qcco.commission.refmodel.TestInitRefModel;

public class AceBodyBeforeEditHandler implements
		IAppEventHandler<CardBodyBeforeEditEvent> {

	@Override
	public void handleAppEvent(CardBodyBeforeEditEvent e) {
		if ("productserial".equals(e.getKey())) {
			BillItem bitem = (BillItem) e.getSource();

			String code = ((UIRefPane) ((BillItem) e.getBillCardPanel()
					.getHeadItem("pk_maincategory")).getComponent())
					.getRefCode();
			((SampleInfoRefModel) ((UIRefPane) bitem.getComponent())
					.getRefModel()).setFirstClassCode(code);
			code = ((UIRefPane) ((BillItem) e.getBillCardPanel().getHeadItem(
					"pk_subcategory")).getComponent()).getRefCode();
			((SampleInfoRefModel) ((UIRefPane) bitem.getComponent())
					.getRefModel()).setSecondClassCode(code);
			code = ((UIRefPane) ((BillItem) e.getBillCardPanel().getHeadItem(
					"pk_lastcategory")).getComponent()).getRefCode();
			((SampleInfoRefModel) ((UIRefPane) bitem.getComponent())
					.getRefModel()).setThirdClassCode(code);
		} else if ("pk_analysisref".equals(e.getKey())) {
			String entStandard = (String) e.getBillCardPanel().getBodyValueAt(
					e.getRow(), "enterprisestandard");
			String productSpec = (String) e.getBillCardPanel().getBodyValueAt(
					e.getRow(), "productspec");
			String productGrade = (String) e.getBillCardPanel().getBodyValueAt(
					e.getRow(), "structuretype");
			String productStage = (String) e.getBillCardPanel().getBodyValueAt(
					e.getRow(), "productstage");

			BillItem bitem = (BillItem) e.getSource();
			((TestInitRefModel) ((UIRefPane) bitem.getComponent())
					.getRefModel()).setEnterpriseStandard(entStandard);
			((TestInitRefModel) ((UIRefPane) bitem.getComponent())
					.getRefModel()).setProductSpec(productSpec);
			((TestInitRefModel) ((UIRefPane) bitem.getComponent())
					.getRefModel()).setProductGrade(productGrade);
			((TestInitRefModel) ((UIRefPane) bitem.getComponent())
					.getRefModel()).setProductStage(productStage);
		}

		e.setReturnValue(true);
	}
}
