package nc.ui.qcco.commission.ace.handler;

import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.bill.BillCellEditor;
import nc.ui.pubapp.uif2app.event.IAppEventHandler;
import nc.ui.pubapp.uif2app.event.card.CardBodyAfterEditEvent;

public class GrandBodyAfterEditHandler implements IAppEventHandler<CardBodyAfterEditEvent> {

	@Override
	public void handleAppEvent(CardBodyAfterEditEvent e) {
		if ("samplegroup".equals(e.getKey())) {
			BillCellEditor bitem = (BillCellEditor) e.getSource();
			UIRefPane refPane = (UIRefPane) bitem.getComponent();
			e.getBillCardPanel().setBodyValueAt(refPane.getRefPK(), e.getRow(), "pk_samplegroup");
		} else if ("component".equals(e.getKey())) {
			BillCellEditor bitem = (BillCellEditor) e.getSource();
			UIRefPane refPane = (UIRefPane) bitem.getComponent();
			e.getBillCardPanel().setBodyValueAt(refPane.getRefPK(), e.getRow(), "pk_component");
		}
		// else if ("valuetype".equals(e.getKey())) {
		// BillCellEditor bitem = (BillCellEditor) e.getSource();
		// UIRefPane refPane = (UIRefPane) bitem.getComponent();
		// e.getBillCardPanel().setBodyValueAt(refPane.getRefPK(), e.getRow(),
		// "pk_valuetype");
		// }
	}
}
