package nc.vo.qcco.task;

import nc.vo.pub.SuperVO;

public class SampleAllocatVO extends SuperVO {
	private String sampleallocat;

	public String getSampleallocat() {
		return sampleallocat;
	}

	public void setSampleallocat(String sampleallocat) {
		this.sampleallocat = sampleallocat;
	}

}
