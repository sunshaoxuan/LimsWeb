package nc.ui.qcco.qcanalyseresult.model;
import nc.ui.uif2.model.BillManageModel;

public class AnalyseResultAppModel extends BillManageModel{

}
