package nc.ui.qcco.commission.ace.handler;

import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.bill.BillItem;
import nc.ui.pubapp.uif2app.event.IAppEventHandler;
import nc.ui.pubapp.uif2app.event.card.CardBodyBeforeEditEvent;
import nc.ui.qcco.commission.refmodel.EntTypeRefModel;
import nc.ui.qcco.commission.refmodel.ProductContactRefModel;
import nc.ui.qcco.commission.refmodel.ProductPointRefModel;
import nc.ui.qcco.commission.refmodel.ProductSerialRefModel;
import nc.ui.qcco.commission.refmodel.ProductStructRefModel;
import nc.ui.qcco.commission.refmodel.ProductTempRefModel;
import nc.ui.qcco.commission.refmodel.TestInitRefModel;

public class AceBodyBeforeEditHandler implements IAppEventHandler<CardBodyBeforeEditEvent> {

	@Override
	public void handleAppEvent(CardBodyBeforeEditEvent e) {
		BillItem bitem = (BillItem) e.getSource();

		if ("productserial".equals(e.getKey())) {
			// ��Ʒϵ��
			String code = ((UIRefPane) ((BillItem) e.getBillCardPanel().getHeadItem("pk_maincategory")).getComponent())
					.getRefCode();
			((ProductSerialRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setFirstClassCode(code);
			code = ((UIRefPane) ((BillItem) e.getBillCardPanel().getHeadItem("pk_subcategory")).getComponent())
					.getRefCode();
			((ProductSerialRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setSecondClassCode(code);
			code = ((UIRefPane) ((BillItem) e.getBillCardPanel().getHeadItem("pk_lastcategory")).getComponent())
					.getRefCode();
			((ProductSerialRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setThirdClassCode(code);
		} else if ("enterprisestandard".equals(e.getKey())) {
			// ��ҵ��׼
			String productserial = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productserial");
			((EntTypeRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basprod_type(productserial);
		} else if ("productspec".equals(e.getKey())) {
			// ����
			String productserial = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productserial");
			String basentype = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_enterprisestandard");
			((ProductPointRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basprod_type(productserial);
			((ProductPointRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basen_type(basentype);
		} else if ("structuretype".equals(e.getKey())) {
			// �ṹ����
			String productserial = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productserial");
			String basentype = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_enterprisestandard");
			String productspec = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productspec");
			((ProductStructRefModel) ((UIRefPane) bitem.getComponent()).getRefModel())
					.setPk_basprod_type(productserial);
			((ProductStructRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basen_type(basentype);
			((ProductStructRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basprod_point(productspec);
		} else if ("contacttype".equals(e.getKey())) {
			// ��������
			String productserial = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productserial");
			String basentype = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_enterprisestandard");
			String productspec = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productspec");
			String productstruct = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_structuretype");
			UIRefPane pane = (UIRefPane) (e.getBillCardPanel().getBodyItem("contacttype").getComponent());
			ProductContactRefModel refModel = (ProductContactRefModel) (pane.getRefModel());
			refModel.setCacheEnabled(false);
			pane.setCacheEnabled(false);
			refModel.setPk_basprod_type(productserial);
			refModel.setPk_basen_type(basentype);
			refModel.setPk_basprod_point(productspec);
			refModel.setPk_basprod_struct(productstruct);
			refModel.reloadData();
			refModel.fireChange();
		} else if ("pk_analysisref".equals(e.getKey())) {
			String entStandard = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "enterprisestandard");
			String productSpec = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "productspec");
			String productGrade = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "structuretype");
			String productStage = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "productstage");
			((TestInitRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setEnterpriseStandard(entStandard);
			((TestInitRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setProductSpec(productSpec);
			((TestInitRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setProductGrade(productGrade);
			((TestInitRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setProductStage(productStage);
		}
		//�¶��ֶβ����޸�
		/*else if ("productstage".equals(e.getKey())) {
			String productserial = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productserial");
			String basentype = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_enterprisestandard");
			String productspec = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productspec");
			String productstruct = (String) e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_structuretype");
			((ProductTempRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basprod_type(productserial);
			((ProductTempRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basen_type(basentype);
			((ProductTempRefModel) ((UIRefPane) bitem.getComponent()).getRefModel()).setPk_basprod_point(productspec);
			((ProductTempRefModel) ((UIRefPane) bitem.getComponent()).getRefModel())
					.setPk_basprod_struct(productstruct);
		}*/
		// if ("enterprisestandard".equals(e.getKey())) {
		// if (StringUtils.isEmpty(((UIRefPane)
		// bitem.getComponent()).getRefPK())) {
		// String productserial = (String)
		// e.getBillCardPanel().getBodyValueAt(e.getRow(), "pk_productserial");
		// ((EntTypeRefModel) ((UIRefPane)
		// bitem.getComponent()).getRefModel()).setPk_basprod_type(productserial);
		// }
		// }

		e.setReturnValue(true);
	}
}
