package nc.ui.pub.qcco.writeback.utils.LIMSVO;


public class Result extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3275285545218726463L;

}
