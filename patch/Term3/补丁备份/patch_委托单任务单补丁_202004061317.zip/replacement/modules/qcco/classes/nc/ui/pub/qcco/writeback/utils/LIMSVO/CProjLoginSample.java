package nc.ui.pub.qcco.writeback.utils.LIMSVO;


public class CProjLoginSample extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2610132857206665636L;
	

}
