package nc.ui.pub.qcco.writeback.utils.LIMSVO;

public class ApprovalInfo extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5995772954462580123L;

}
