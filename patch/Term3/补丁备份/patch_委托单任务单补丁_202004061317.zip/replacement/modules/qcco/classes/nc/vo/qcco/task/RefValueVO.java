package nc.vo.qcco.task;

import nc.vo.pub.SuperVO;

public class RefValueVO extends SuperVO {
	private String chinaname;
	private String code;
	private String engname;
	public String getChinaname() {
		return chinaname;
	}
	public void setChinaname(String chinaname) {
		this.chinaname = chinaname;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getEngname() {
		return engname;
	}
	public void setEngname(String engname) {
		this.engname = engname;
	}
	

	

}
