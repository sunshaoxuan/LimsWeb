package nc.ui.pub.qcco.writeback.utils.LIMSVO;

public class CProjTask extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1566956872166733137L;

}
