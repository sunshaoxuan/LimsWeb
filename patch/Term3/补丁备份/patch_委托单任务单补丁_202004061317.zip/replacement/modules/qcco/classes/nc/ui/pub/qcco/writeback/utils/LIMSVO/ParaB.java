package nc.ui.pub.qcco.writeback.utils.LIMSVO;


public class ParaB extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 669054190115029133L;

}
