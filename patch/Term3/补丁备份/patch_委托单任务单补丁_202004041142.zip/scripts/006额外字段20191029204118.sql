alter table qc_task_h add billstatus int  ;
alter table qc_task_s add pk_testconditionitem_back varchar(50);