package nc.bs.qcco.pub.rule;

import nc.bs.framework.common.NCLocator;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.itf.uap.IUAPQueryBS;
import nc.jdbc.framework.processor.ColumnProcessor;
import nc.vo.pub.BusinessException;
import nc.vo.pub.ISuperVO;
import nc.vo.qcco.task.AggTaskHVO;
import nc.vo.qcco.task.TaskBVO;
import nc.vo.qcco.task.TaskSVO;


public class TaskBeforeRule implements IRule<AggTaskHVO> {

	@Override
	public void process(AggTaskHVO[] aggVOs) {
		checkUnit(aggVOs);
	}

	/**
	 * ��ֵ����Ϊ���ı���ʱ�������λΪ�գ���ôԤ��ΪNONE
	 * @param aggVOs
	 */
	private void checkUnit(AggTaskHVO[] aggVOs) {
		//�����ı�����
		String sql = " select trim(pk_result_type)  from nc_result_type  where trim(nc_result_namecn) = '�ı�'";
		IUAPQueryBS bs = NCLocator.getInstance().lookup(IUAPQueryBS.class);
		String stringPk = null;
		try {
			stringPk = (String) bs.executeQuery(sql, new ColumnProcessor());
		} catch (BusinessException e) {
			stringPk = null;
		}
		if(stringPk==null){
			return;
		}
		if(aggVOs != null&&aggVOs.length > 0) {
			for(AggTaskHVO aggvo : aggVOs){
				if(aggvo!=null && aggvo.getChildren(TaskBVO.class)!=null){
					ISuperVO[] bvos = aggvo.getChildren(TaskBVO.class);
					for(ISuperVO bvo : bvos){
						TaskBVO taskBvo = (TaskBVO)bvo;
						if(taskBvo!=null && taskBvo.getPk_task_s()!=null){
							TaskSVO[] svos = taskBvo.getPk_task_s();
							for(TaskSVO svo: svos){
								if(svo.getPk_valuetype()!=null && svo.getPk_valuetype().trim().equals(stringPk) && 
										(svo.getUnit()==null || svo.getUnit().length() <=0)){
									svo.setUnit("NONE");
								}
							}
						}
					}
				}
			}
		}
		
	}



}
