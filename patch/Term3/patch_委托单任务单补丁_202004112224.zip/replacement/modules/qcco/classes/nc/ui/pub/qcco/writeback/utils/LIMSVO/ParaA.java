package nc.ui.pub.qcco.writeback.utils.LIMSVO;


public class ParaA extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8945974049727158245L;

}
