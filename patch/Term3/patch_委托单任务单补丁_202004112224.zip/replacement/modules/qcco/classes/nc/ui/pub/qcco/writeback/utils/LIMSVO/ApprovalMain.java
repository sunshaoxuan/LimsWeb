package nc.ui.pub.qcco.writeback.utils.LIMSVO;

public class ApprovalMain extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6398757489366154621L;

}
