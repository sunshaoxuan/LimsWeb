package nc.ui.pub.qcco.writeback.utils.LIMSVO;



public class Sample extends LIMSCommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7671922432807444246L;

}
