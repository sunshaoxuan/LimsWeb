package nc.ui.pub.qcco.writeback.utils.LIMSVO;

/**
 * 
 * @author 91967
 *
 */
public class Project extends LIMSCommonVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5697559460265199279L;
}
