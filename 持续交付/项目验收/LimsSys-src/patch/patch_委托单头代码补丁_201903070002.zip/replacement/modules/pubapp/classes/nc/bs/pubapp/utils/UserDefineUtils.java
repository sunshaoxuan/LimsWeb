package nc.bs.pubapp.utils;

import java.util.List;
import java.util.Vector;

import nc.ui.bd.ref.AbstractRefModel;
import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.beans.UITable;
import nc.ui.pub.beans.constenum.DefaultConstEnum;
import nc.ui.pub.beans.constenum.IConstEnum;
import nc.ui.pub.bill.BillItem;
import nc.ui.pubapp.uif2app.view.BillForm;
import nc.ui.uif2.editor.BillListView;
import nc.vo.pub.BusinessException;
import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.ISuperVO;
import nc.vo.pub.SuperVO;
import uap.iweb.log.Logger;

public class UserDefineUtils {
	public static void refreshGrandDefRefs(BillForm grandBillForm, String grandTabCode, List<Object> grandVOList) {
		int row = grandBillForm.getBillCardPanel().getBillModel().getRowCount();
		for (int i = 0; i < row; i++) {
			CircularlyAccessibleValueObject vo = grandBillForm.getBillCardPanel().getBillModel()
					.getBodyValueRowVOByVisualValue(i, grandVOList.get(0).getClass().getName());
			try {
				ISuperVO superVO = getSuperVOByPK(grandVOList, vo.getPrimaryKey());
				for (BillItem billItem : grandBillForm.getBillCardPanel().getBillModel().getBodyItems()) {
					UserDefineUtils.refreshItemRefValue(superVO,
							grandBillForm.getBillCardPanel().getBillTable(grandTabCode), i, billItem, true);
				}
			} catch (BusinessException e) {
				Logger.error(e.getMessage());
			}
		}
	}

	public static void refreshGrandDefRefs(BillListView grandListView, List<Object> grandVOList) {
		int row = grandListView.getBillListPanel().getBodyBillModel().getRowCount();
		for (int i = 0; i < row; i++) {
			CircularlyAccessibleValueObject vo = grandListView.getBillListPanel().getBodyBillModel()
					.getBodyValueRowVOByVisualValue(i, grandVOList.get(0).getClass().getName());
			try {
				ISuperVO superVO = getSuperVOByPK(grandVOList, vo.getPrimaryKey());
				for (BillItem billItem : grandListView.getBillListPanel().getBodyBillModel().getBodyItems()) {
					UserDefineUtils.refreshItemRefValue(superVO, grandListView.getBillListPanel().getBodyTable(), i,
							billItem, true);
				}
			} catch (BusinessException e) {
				Logger.error(e.getMessage());
			}
		}
	}

	private static ISuperVO getSuperVOByPK(List<Object> grandVOList, String primaryKey) {
		for (Object obj : grandVOList) {
			String pk = (String) ((SuperVO) obj).getAttributeValue(((SuperVO) obj).getPKFieldName());
			if (primaryKey.equals(pk)) {
				return (ISuperVO) obj;
			}
		}
		return null;
	}

	public static void refreshItemRefValue(ISuperVO vo, UITable uiTable, int row, BillItem billItem,
			boolean onlyDisplayItem) {
		if (vo != null && billItem != null && (!onlyDisplayItem || billItem.isShow())) {
			if (billItem.getComponent() instanceof UIRefPane) {
				UIRefPane pane = (UIRefPane) billItem.getComponent();
				AbstractRefModel refModel = pane.getRefModel();
				if (refModel != null && vo.getAttributeValue(billItem.getKey()) != null) {
					Vector refvls = refModel.matchData(refModel.getPkFieldCode(),
							(String) vo.getAttributeValue(billItem.getKey()));
					if (null != refvls) {
						IConstEnum val = new DefaultConstEnum(((Vector) refvls.get(0)).get(0),
								(String) ((Vector) refvls.get(0)).get(1));
						for (int col = 0; col < uiTable.getColumnCount(); col++) {
							if (uiTable.getColumnName(col).equals(billItem.getName())) {
								uiTable.setValueAt(val, row, col);
							}
						}
					}
				}
			}
		}
	}

}
