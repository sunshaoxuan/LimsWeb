package nc.ui.qcco.commission.ace.view;

import java.util.HashMap;

import nc.bs.framework.common.NCLocator;
import nc.bs.pubapp.utils.UserDefineUtils;
import nc.itf.pubapp.uif2app.components.grand.IGrandAggVosQueryService;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.bill.BillListPanel;
import nc.ui.pubapp.uif2app.components.grand.MainGrandRelationShip;
import nc.ui.pubapp.uif2app.event.list.ListBodyRowChangedEvent;
import nc.ui.pubapp.uif2app.event.list.ListHeadRowChangedEvent;
import nc.ui.pubapp.uif2app.view.ShowUpableBillListView;
import nc.ui.uif2.AppEvent;
import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.ISuperVO;
import nc.vo.qcco.commission.AggCommissionHVO;
import nc.vo.qcco.commission.CommissionBVO;
import nc.vo.qcco.commission.CommissionRVO;

import org.apache.commons.lang.StringUtils;

public class MainBillList extends ShowUpableBillListView {
	private ShowUpableBillListView grandBillList;
	private MainGrandRelationShip mainGrandRelationShip;

	public void handleEvent(AppEvent event) {
		super.handleEvent(event);

		AggCommissionHVO aggvo = getFullAggVO();
		if (aggvo != null) {
			if (event instanceof ListHeadRowChangedEvent) {
				BillListPanel listPanel = ((ListHeadRowChangedEvent) event).getBillListPanel();
				// �����ͷ�У���������
				for (int row = 0; row < listPanel.getBodyBillModel().getRowCount(); row++) {
					CommissionBVO bodyVO = (CommissionBVO) listPanel.getBodyBillModel().getBodyValueRowVO(row,
							CommissionBVO.class.getName());
					ISuperVO[] aggBodies = aggvo.getChildren(CommissionBVO.class);
					CommissionBVO fullBodyVO = null;
					for (ISuperVO realBody : aggBodies) {
						if (bodyVO.getPk_commission_b().equals(realBody.getAttributeValue("pk_commission_b"))) {
							fullBodyVO = (CommissionBVO) realBody;
							break;
						}
					}
					for (BillItem item : listPanel.getBodyBillModel().getBodyItems()) {
						if (!StringUtils.isEmpty(item.getRefType()) && item.getRefType().contains("<")) {
							UserDefineUtils.refreshItemRefValue(fullBodyVO, listPanel.getBodyTable(), row, item, true);
						}
					}
				}

				refreshGrandRows(aggvo, (CommissionBVO) aggvo.getChildren(CommissionBVO.class)[0], listPanel);
			} else if (event instanceof ListBodyRowChangedEvent) {
				// ��������У���������
				// CommissionBVO bodyVO = (CommissionBVO)
				// ((ListBodyRowChangedEvent) event)
				// .getBillListPanel()
				// .getBodyBillModel()
				// .getBodyValueRowVOByVisualValue(((ListBodyRowChangedEvent)
				// event).getRow(),
				// CommissionBVO.class.getName());
				// refreshGrandRows(aggvo, bodyVO,
				// this.getGrandBillList().getBillListPanel());
			}
		}
	}

	private void refreshGrandRows(AggCommissionHVO aggvo, CommissionBVO bodyVO, BillListPanel listPanel) {
		ISuperVO[] aggBodies = aggvo.getChildren(CommissionBVO.class);
		CommissionBVO fullBodyVO = null;
		for (ISuperVO realBody : aggBodies) {
			if (bodyVO.getPk_commission_b().equals(realBody.getAttributeValue("pk_commission_b"))) {
				fullBodyVO = (CommissionBVO) realBody;
				break;
			}
		}
		for (int i = 0; i < listPanel.getBodyBillModel().getRowCount(); i++) {
			CircularlyAccessibleValueObject emtvo = listPanel.getBodyBillModel().getBodyValueRowVO(i,
					CommissionRVO.class.getName());
			for (CommissionRVO rvo : fullBodyVO.getPk_commission_r()) {
				if (rvo.getPk_commission_r().equals(emtvo.getAttributeValue("pk_commission_r"))) {
					for (BillItem item : listPanel.getBodyBillModel().getBodyItems()) {
						if (!StringUtils.isEmpty(item.getRefType()) && item.getRefType().contains("<")) {
							UserDefineUtils
									.refreshItemRefValue((ISuperVO) rvo, listPanel.getBodyTable(), i, item, true);
						}
					}
				}
			}
		}
	}

	private AggCommissionHVO getFullAggVO() {
		AggCommissionHVO aggvo = (AggCommissionHVO) this.getModel().getSelectedData();
		if (aggvo != null) {
			IGrandAggVosQueryService queryService = (IGrandAggVosQueryService) NCLocator.getInstance().lookup(
					IGrandAggVosQueryService.class);
			aggvo = (AggCommissionHVO) queryService.getAllListGrandVOS(aggvo,
					(HashMap) mainGrandRelationShip.getGrandTabAndVOMap());
		}
		return aggvo;
	}

	public ShowUpableBillListView getGrandBillList() {
		return grandBillList;
	}

	public void setGrandBillList(ShowUpableBillListView grandBillList) {
		this.grandBillList = grandBillList;
	}

	public MainGrandRelationShip getMainGrandRelationShip() {
		return mainGrandRelationShip;
	}

	public void setMainGrandRelationShip(MainGrandRelationShip mainGrandRelationShip) {
		this.mainGrandRelationShip = mainGrandRelationShip;
	}
}
