package nc.ui.qcco.commission.action;

import java.awt.event.ActionEvent;

import nc.ui.pub.beans.MessageDialog;
import nc.ui.uif2.NCAction;
import nc.ui.uif2.UIState;
import nc.ui.uif2.editor.BillListView;
import nc.vo.pub.SuperVO;
import nc.vo.pubapp.pattern.model.entity.bill.AbstractBill;

public class EditTaskAction extends NCAction {

	/**
	 * serial no
	 */
	private static final long serialVersionUID = 7999906859786627909L;
	private BillListView billListPanel;

	public EditTaskAction() {
		this.setCode("EDITTASKACTION");
		this.setBtnName("����ά��");
	}

	@Override
	public void doAction(ActionEvent e) throws Exception {
		if (this.getBillListPanel().getModel().getSelectedRow() >= 0) {
			if (MessageDialog.showOkCancelDlg(this.getBillListPanel(), "ά������", "�Ƿ�༭��ǰί�е���Ӧ�����񵥣�") == MessageDialog.ID_OK) {

			}
		}
	}

	public BillListView getBillListPanel() {
		return billListPanel;
	}

	public void setBillListPanel(BillListView billListPanel) {
		this.billListPanel = billListPanel;
		this.billListPanel.getModel().addAppEventListener(this);
	}

	protected boolean isActionEnable() {
		AbstractBill aggVO = (AbstractBill) this.getBillListPanel().getModel().getSelectedData();
		if (aggVO == null) {
			return false;
		}
		SuperVO hvo = (SuperVO) aggVO.getParentVO();
		if (hvo == null) {
			return false;
		}
		return this.getBillListPanel().getModel().getUiState() == UIState.NOT_EDIT;
	}
}
